import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppProvider } from "@/lib/context";
import Navbar from "@/components/Navbar";

import IntroPage from "@/pages/IntroPage";
import SelectionPage from "@/pages/SelectionPage";
import TranslationPage from "@/pages/TranslationPage";
import VisualPage from "@/pages/VisualPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="pb-20 md:pb-0 md:pt-20"> {/* Add padding for fixed navbar */}
      <Switch>
        <Route path="/" component={IntroPage} />
        <Route path="/select" component={SelectionPage} />
        <Route path="/translate" component={TranslationPage} />
        <Route path="/visual" component={VisualPage} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppProvider>
        <TooltipProvider>
          <Toaster />
          <Navbar />
          <Router />
        </TooltipProvider>
      </AppProvider>
    </QueryClientProvider>
  );
}

export default App;
