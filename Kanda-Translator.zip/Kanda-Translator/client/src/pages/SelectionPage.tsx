import { motion } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { shlokas } from '@/data/shlokas';
import { useApp } from '@/lib/context';
import { BookOpen, Languages, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function SelectionPage() {
  const { currentShloka, setCurrentShloka, language, setLanguage } = useApp();

  return (
    <div className="min-h-screen pt-20 pb-24 px-4 bg-background flex flex-col items-center justify-center">
      <motion.div 
        className="w-full max-w-3xl space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center space-y-2 mb-12">
          <h2 className="text-3xl md:text-5xl font-display text-primary">Select Your Verse</h2>
          <p className="text-muted-foreground font-serif">Choose a sacred shloka and your preferred language.</p>
        </div>

        <Card className="border-none shadow-xl bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl font-serif">
              <BookOpen className="w-5 h-5 text-primary" />
              Choose Shloka
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select 
              value={currentShloka.id} 
              onValueChange={(val) => {
                const found = shlokas.find(s => s.id === val);
                if (found) setCurrentShloka(found);
              }}
            >
              <SelectTrigger className="h-16 text-lg font-serif bg-background border-border shadow-sm">
                <SelectValue placeholder="Select a Shloka" />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                {shlokas.map((s) => (
                  <SelectItem key={s.id} value={s.id} className="font-serif py-3 cursor-pointer">
                    <span className="font-bold text-primary mr-2">{s.id}.</span> {s.context}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="border-none shadow-xl bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl font-serif">
              <Languages className="w-5 h-5 text-primary" />
              Target Language
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="h-16 text-lg font-sans bg-background border-border shadow-sm">
                <SelectValue placeholder="Select Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="english" className="py-3 text-lg">English</SelectItem>
                <SelectItem value="hindi" className="py-3 text-lg">Hindi (हिंदी)</SelectItem>
                <SelectItem value="telugu" className="py-3 text-lg">Telugu (తెలుగు)</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <div className="flex justify-end pt-4">
          <Link href="/translate">
            <Button size="lg" className="text-lg px-8 rounded-full shadow-lg hover:scale-105 transition-transform">
              See Translation <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
