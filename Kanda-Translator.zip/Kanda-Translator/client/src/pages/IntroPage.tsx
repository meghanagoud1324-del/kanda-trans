import { motion } from 'framer-motion';
import heroImage from '@assets/generated_images/divine_ram_sita_hanuman.png';
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function IntroPage() {
  return (
    <div className="min-h-screen relative flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Divine Ram Sita Hanuman" 
          className="w-full h-full object-cover opacity-90 scale-105 animate-in fade-in duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-background" />
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center text-white space-y-8 max-w-4xl px-4 mt-[-50px]">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <span className="inline-block py-1 px-4 border border-white/30 rounded-full text-sm font-serif tracking-widest uppercase bg-black/30 backdrop-blur-md mb-6">
            Sundara Kanda • Chapter 1
          </span>
        </motion.div>
        
        <motion.h1 
          className="text-5xl md:text-8xl font-display font-bold text-primary-foreground drop-shadow-2xl tracking-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          Hanuman's<br />Departure
        </motion.h1>
        
        <motion.div 
          className="space-y-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
        >
          <p className="text-xl md:text-2xl font-serif italic text-white/90 max-w-2xl mx-auto leading-relaxed border-l-2 border-primary pl-6 text-left md:text-center md:border-l-0 md:pl-0">
            "To cross the impossible ocean, one needs faith as vast as the sky."
          </p>
          
          <div className="pt-8">
            <Link href="/select">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg px-8 py-6 rounded-full shadow-[0_0_20px_rgba(255,165,0,0.3)] transition-all hover:scale-105 group">
                Begin Journey <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
