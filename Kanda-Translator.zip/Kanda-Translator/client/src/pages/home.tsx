import ShlokaTranslator from "@/components/ShlokaTranslator";

export default function Home() {
  return <ShlokaTranslator />;
}
