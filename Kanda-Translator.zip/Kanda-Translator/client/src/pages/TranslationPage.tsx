import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '@/lib/context';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Pause, Volume2, ArrowRight } from 'lucide-react';
import { Link } from "wouter";

export default function TranslationPage() {
  const { currentShloka, language } = useApp();
  const [isPlaying, setIsPlaying] = useState(false);

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      
      if (isPlaying) {
        setIsPlaying(false);
        return;
      }

      // Speak Sanskrit
      const sanskritUtterance = new SpeechSynthesisUtterance(currentShloka.sanskrit);
      sanskritUtterance.lang = 'hi-IN'; 
      sanskritUtterance.rate = 0.8;
      
      // Speak Translation
      const translationText = currentShloka.translation[language as keyof typeof currentShloka.translation];
      const transUtterance = new SpeechSynthesisUtterance(translationText);
      transUtterance.lang = language === 'english' ? 'en-US' : (language === 'telugu' ? 'te-IN' : 'hi-IN');
      
      sanskritUtterance.onend = () => {
        window.speechSynthesis.speak(transUtterance);
      };
      
      transUtterance.onend = () => {
        setIsPlaying(false);
      };

      setIsPlaying(true);
      window.speechSynthesis.speak(sanskritUtterance);
    } else {
      alert("Text-to-Speech not supported in this browser.");
    }
  };

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    };
  }, [currentShloka.id, language]);

  return (
    <div className="min-h-screen pt-20 pb-24 px-4 bg-secondary/30 flex flex-col items-center justify-center">
      <motion.div 
        className="max-w-4xl w-full space-y-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center space-y-2 mb-8">
           <span className="inline-block py-1 px-3 border border-primary/20 rounded-full text-xs font-bold tracking-widest text-primary uppercase bg-primary/5 mb-2">
            Verse {currentShloka.id}
          </span>
          <h2 className="text-2xl md:text-4xl font-display text-foreground">{currentShloka.context}</h2>
        </div>

        {/* Sanskrit Card */}
        <motion.div
          key={currentShloka.id + 'sanskrit'}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="overflow-hidden border-none shadow-lg bg-card/80 backdrop-blur-sm">
            <CardContent className="p-8 md:p-12 text-center relative">
              <div className="absolute top-4 left-4 text-[100px] leading-none text-primary/5 font-serif select-none">“</div>
              <p className="text-3xl md:text-4xl font-sanskrit font-bold text-foreground leading-relaxed whitespace-pre-line relative z-10">
                {currentShloka.sanskrit}
              </p>
              <div className="absolute bottom-4 right-4 text-[100px] leading-none text-primary/5 font-serif select-none rotate-180">“</div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Translation Card */}
        <motion.div
          key={currentShloka.id + language}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="overflow-hidden border-l-4 border-primary shadow-md bg-background">
            <CardContent className="p-8 md:p-10 flex flex-col md:flex-row gap-8 items-center justify-between">
              <div className="space-y-4 flex-1">
                <span className="text-xs font-bold tracking-widest text-muted-foreground uppercase flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  {language.charAt(0).toUpperCase() + language.slice(1)} Translation
                </span>
                <p className="text-xl md:text-2xl font-serif text-foreground/90 leading-relaxed">
                  {currentShloka.translation[language as keyof typeof currentShloka.translation]}
                </p>
              </div>
              
              <Button 
                size="lg" 
                variant={isPlaying ? "destructive" : "default"}
                className="rounded-full w-20 h-20 flex-shrink-0 shadow-xl transition-all hover:scale-105"
                onClick={handleSpeak}
              >
                {isPlaying ? <Pause className="w-8 h-8" /> : <Volume2 className="w-8 h-8" />}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <div className="flex justify-end pt-4">
          <Link href="/visual">
            <Button size="lg" className="text-lg px-8 rounded-full shadow-lg hover:scale-105 transition-transform">
              View Visualization <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>

      </motion.div>
    </div>
  );
}
