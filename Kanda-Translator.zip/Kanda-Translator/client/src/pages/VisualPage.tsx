import { motion } from 'framer-motion';
import { useApp } from '@/lib/context';
import heroImage from '@assets/generated_images/divine_ram_sita_hanuman.png';
import flightImage from '@assets/generated_images/hanuman_flying_over_ocean.png';
// We will use placeholders for new images until they are generated, or reuse existing ones if generation fails/is limited. 
// For now, I'll map them to the generated assets.
// In a real scenario, I'd import the newly generated images here. 
// Since I just requested them, I will add imports for them assuming the tool works as expected.

import mountainImage from '@assets/generated_images/hanuman_pressing_mainaka_mountain.png';
import surasaImage from '@assets/generated_images/hanuman_entering_surasa_mouth.png';
import simhikaImage from '@assets/generated_images/hanuman_fighting_simhika.png';
import lankaImage from '@assets/generated_images/beautiful_lanka_on_mountain.png';

export default function VisualPage() {
  const { currentShloka } = useApp();

  const getImage = (type: string) => {
    switch (type) {
      case 'divine': return heroImage;
      case 'departure': return flightImage;
      case 'mountain': return mountainImage;
      case 'surasa': return surasaImage;
      case 'simhika': return simhikaImage;
      case 'lanka': return lankaImage;
      default: return flightImage;
    }
  };

  const imageSrc = getImage(currentShloka.imageType);

  return (
    <div className="min-h-screen pt-20 pb-24 px-4 bg-background flex flex-col items-center justify-center">
       <motion.div 
        className="max-w-6xl w-full space-y-8 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="space-y-4 mb-8">
          <h2 className="text-3xl md:text-5xl font-display text-primary">Visualizing the Verse</h2>
          <p className="text-muted-foreground font-serif text-lg max-w-2xl mx-auto">
             Witness the moment described in <strong>Verse {currentShloka.id}</strong>.
          </p>
        </div>

        <motion.div 
          key={currentShloka.id}
          className="relative w-full aspect-video rounded-2xl overflow-hidden shadow-2xl border-4 border-white ring-1 ring-border group"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          <img 
            src={imageSrc} 
            alt={currentShloka.context}
            className="w-full h-full object-cover transition-transform duration-[15s] group-hover:scale-110 ease-out"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end justify-center p-8 md:p-12">
            <p className="text-white text-xl md:text-3xl font-display tracking-wide drop-shadow-lg">
              {currentShloka.context}
            </p>
          </div>
        </motion.div>

      </motion.div>
    </div>
  );
}
