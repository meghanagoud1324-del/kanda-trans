import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, Volume2, ChevronDown, BookOpen, Languages } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { shlokas, Shloka } from '@/data/shlokas';
import heroImage from '@assets/generated_images/divine_ram_sita_hanuman.png';
import flightImage from '@assets/generated_images/hanuman_flying_over_ocean.png';

// --- Module 1: Motto & Title ---
const HeroModule = () => {
  return (
    <div className="relative h-[80vh] w-full overflow-hidden flex items-center justify-center">
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Divine Ram Sita Hanuman" 
          className="w-full h-full object-cover opacity-90 scale-105 animate-in fade-in duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-background" />
      </div>
      
      <div className="relative z-10 text-center text-white space-y-6 max-w-4xl px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <span className="inline-block py-1 px-3 border border-white/30 rounded-full text-sm font-serif tracking-widest uppercase bg-black/20 backdrop-blur-md mb-4">
            Sundara Kanda
          </span>
        </motion.div>
        
        <motion.h1 
          className="text-5xl md:text-7xl font-display font-bold text-primary-foreground drop-shadow-2xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          The Great Departure
        </motion.h1>
        
        <motion.p 
          className="text-xl md:text-2xl font-serif italic text-white/90 max-w-2xl mx-auto leading-relaxed"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
        >
          "To cross the impossible ocean, one needs faith as vast as the sky."
        </motion.p>
      </div>
    </div>
  );
};

// --- Module 2: Selection ---
const SelectionModule = ({ 
  currentShloka, 
  setCurrentShloka, 
  language, 
  setLanguage 
}: { 
  currentShloka: Shloka, 
  setCurrentShloka: (s: Shloka) => void, 
  language: string, 
  setLanguage: (l: string) => void 
}) => {
  return (
    <section className="py-12 px-4 bg-background border-b border-border/40">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Select Verse
            </label>
            <Select 
              value={currentShloka.id} 
              onValueChange={(val) => {
                const found = shlokas.find(s => s.id === val);
                if (found) setCurrentShloka(found);
              }}
            >
              <SelectTrigger className="h-14 text-lg font-serif bg-card border-border/50 shadow-sm">
                <SelectValue placeholder="Select a Shloka" />
              </SelectTrigger>
              <SelectContent>
                {shlokas.map((s) => (
                  <SelectItem key={s.id} value={s.id} className="font-serif">
                    Verse {s.id}: {s.context}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
              <Languages className="w-4 h-4" /> Target Language
            </label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="h-14 text-lg font-sans bg-card border-border/50 shadow-sm">
                <SelectValue placeholder="Select Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="english">English</SelectItem>
                <SelectItem value="hindi">Hindi</SelectItem>
                <SelectItem value="telugu">Telugu</SelectItem>
              </SelectContent>
            </Select>
          </div>

        </div>
      </div>
    </section>
  );
};

// --- Module 3: Translation & Audio ---
const TranslationModule = ({ 
  shloka, 
  language 
}: { 
  shloka: Shloka, 
  language: string 
}) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // Stop any current speech
      
      if (isPlaying) {
        setIsPlaying(false);
        return;
      }

      // Speak Sanskrit first
      const sanskritUtterance = new SpeechSynthesisUtterance(shloka.sanskrit);
      sanskritUtterance.lang = 'hi-IN'; // Hindi voice usually handles Sanskrit reasonably well
      sanskritUtterance.rate = 0.8;
      
      // Speak Translation
      const translationText = shloka.translation[language as keyof typeof shloka.translation];
      const transUtterance = new SpeechSynthesisUtterance(translationText);
      transUtterance.lang = language === 'english' ? 'en-US' : (language === 'telugu' ? 'te-IN' : 'hi-IN');
      
      sanskritUtterance.onend = () => {
        window.speechSynthesis.speak(transUtterance);
      };
      
      transUtterance.onend = () => {
        setIsPlaying(false);
      };

      setIsPlaying(true);
      window.speechSynthesis.speak(sanskritUtterance);
    } else {
      alert("Text-to-Speech not supported in this browser.");
    }
  };

  useEffect(() => {
    // Cleanup on unmount or change
    return () => {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    };
  }, [shloka.id, language]);

  return (
    <section className="py-16 px-4 bg-secondary/30">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Sanskrit Card */}
        <motion.div
          key={shloka.id + 'sanskrit'}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="overflow-hidden border-none shadow-lg bg-card/80 backdrop-blur-sm">
            <CardContent className="p-8 md:p-12 text-center space-y-6">
              <span className="text-xs font-bold tracking-widest text-primary uppercase">Original Sanskrit</span>
              <p className="text-3xl md:text-4xl font-sanskrit font-bold text-foreground leading-relaxed whitespace-pre-line">
                {shloka.sanskrit}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Translation Card */}
        <motion.div
          key={shloka.id + language}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="overflow-hidden border-l-4 border-primary shadow-md bg-white">
            <CardContent className="p-8 md:p-10 flex flex-col md:flex-row gap-8 items-center justify-between">
              <div className="space-y-4 flex-1">
                <span className="text-xs font-bold tracking-widest text-muted-foreground uppercase">
                  {language.charAt(0).toUpperCase() + language.slice(1)} Translation
                </span>
                <p className="text-xl md:text-2xl font-serif text-foreground/90 leading-relaxed">
                  {shloka.translation[language as keyof typeof shloka.translation]}
                </p>
              </div>
              
              <Button 
                size="lg" 
                variant={isPlaying ? "destructive" : "default"}
                className="rounded-full w-16 h-16 flex-shrink-0 shadow-xl transition-all hover:scale-105"
                onClick={handleSpeak}
              >
                {isPlaying ? <Pause className="w-8 h-8" /> : <Volume2 className="w-8 h-8" />}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

      </div>
    </section>
  );
};

// --- Module 4: Contextual Image ---
const VisualModule = ({ shloka }: { shloka: Shloka }) => {
  const imageSrc = shloka.imageType === 'divine' ? heroImage : flightImage;

  return (
    <section className="py-24 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col items-center text-center space-y-12">
          
          <div className="space-y-4 max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-display text-primary">Visualizing the Verse</h2>
            <p className="text-muted-foreground font-serif text-lg">
              Witness the moment described in the sacred verses.
            </p>
          </div>

          <motion.div 
            key={shloka.id}
            className="relative w-full max-w-4xl aspect-video rounded-2xl overflow-hidden shadow-2xl border-4 border-white ring-1 ring-border"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
          >
            <img 
              src={imageSrc} 
              alt={shloka.context}
              className="w-full h-full object-cover transition-transform duration-[10s] hover:scale-110 ease-out"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-8">
              <p className="text-white text-lg font-medium tracking-wide">
                {shloka.context}
              </p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default function ShlokaTranslator() {
  const [currentShloka, setCurrentShloka] = useState<Shloka>(shlokas[0]);
  const [language, setLanguage] = useState<string>("english");

  return (
    <main className="min-h-screen bg-background selection:bg-primary/30">
      <HeroModule />
      <SelectionModule 
        currentShloka={currentShloka} 
        setCurrentShloka={setCurrentShloka}
        language={language}
        setLanguage={setLanguage}
      />
      <TranslationModule 
        shloka={currentShloka}
        language={language}
      />
      <VisualModule shloka={currentShloka} />
      
      <footer className="py-8 text-center text-muted-foreground text-sm font-serif border-t border-border">
        <p>Jai Shri Ram • Jai Hanuman</p>
      </footer>
    </main>
  );
}
