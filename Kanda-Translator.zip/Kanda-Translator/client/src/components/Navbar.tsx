import { Link, useLocation } from "wouter";
import { Home, BookOpen, Languages, Image as ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Intro", icon: Home },
    { href: "/select", label: "Select Verse", icon: BookOpen },
    { href: "/translate", label: "Translation", icon: Languages },
    { href: "/visual", label: "Visualization", icon: ImageIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 md:top-0 md:bottom-auto z-50 bg-background/80 backdrop-blur-lg border-t md:border-b border-border p-2 md:p-4 shadow-lg">
      <div className="max-w-4xl mx-auto flex justify-around md:justify-center md:gap-12">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <a className={cn(
                "flex flex-col md:flex-row items-center gap-1 md:gap-3 p-2 md:px-4 md:py-2 rounded-lg transition-all duration-300",
                isActive 
                  ? "text-primary bg-primary/10 font-medium" 
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              )}>
                <Icon className={cn("w-5 h-5", isActive && "fill-current")} />
                <span className="text-[10px] md:text-sm uppercase tracking-wider">{item.label}</span>
              </a>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
