export interface Shloka {
  id: string;
  sanskrit: string;
  context: string;
  translation: {
    english: string;
    hindi: string;
    telugu: string;
  };
  imageType: 'divine' | 'departure' | 'mountain' | 'surasa' | 'simhika' | 'lanka'; 
}

export const shlokas: Shloka[] = [
  {
    id: "1",
    context: "Hanuman prepares to leap.",
    sanskrit: "नमोऽस्तु रामाय सलक्ष्मणाय देव्यै च तस्यै जनकात्मजायै ।\nनमोऽस्तु रुद्रेन्द्रयमानिलेभ्यो नमोऽस्तु चन्द्रार्कमरुद्गणेभ्यः ॥",
    translation: {
      english: "Salutations to Rama with Lakshmana, and to Goddess Sita. Salutations to Rudra, Indra, Yama, and Vayu. Salutations to the Moon, Sun, and Marut Ganas.",
      hindi: "राम और लक्ष्मण को नमस्कार, तथा जनकपुत्री सीता देवी को नमस्कार। रुद्र, इंद्र, यम और वायु को नमस्कार। चंद्र, सूर्य और मरुद्गणों को नमस्कार।",
      telugu: "రామునికి, లక్ష్మణునితో కూడిన సీతాదేవికి నమస్కారం. రుద్రుడు, ఇంద్రుడు, యముడు, వాయువులకు నమస్కారం. చంద్రుడు, సూర్యుడు, మరుద్గణాలకు నమస్కారం."
    },
    imageType: 'divine'
  },
  {
    id: "2",
    context: "Hanuman resolves to depart.",
    sanskrit: "स सूर्याय महेन्द्राय पवनाय स्वयंभुवे ।\nभूतेभ्यश्चाञ्जलिं कृत्वा चकार गमने मतिम् ॥",
    translation: {
      english: "Offering salutations to the Sun, Indra, Wind God, Brahma, and all beings, he made up his mind to depart.",
      hindi: "सूर्य, महेंद्र, पवन, स्वयंभू और समस्त प्राणियों को प्रणाम करके उन्होंने जाने का निश्चय किया।",
      telugu: "సూర్యుడు, మహేంద్రుడు, వాయుదేవుడు, స్వయంభువుడు మరియు సమస్త ప్రాణులకు అంజలి ఘటించి, ఆయన బయలుదేరడానికి నిశ్చయించుకున్నారు."
    },
    imageType: 'departure'
  },
  {
    id: "3",
    context: "The earth trembles at his force.",
    sanskrit: "यत्र वानरवीरोऽसौ विचचारानिलात्मजः ।\nधरा तत्राम्बुदाकीर्णा कम्पते मारुताहता ॥",
    translation: {
      english: "Wherever the Wind-son moved, the earth, covered with clouds, trembled as if struck by the wind.",
      hindi: "जहाँ-जहाँ वे वायुपुत्र विचरते थे, वहाँ पृथ्वी वायु के आघात से काँप उठती थी।",
      telugu: "ఆ వాయుపుత్రుడు సంచరించిన చోటల్లా, భూమి గాలి దెబ్బకు వణికేది."
    },
    imageType: 'departure'
  },
  {
    id: "4",
    context: "Hanuman presses Mount Mahendra.",
    sanskrit: "स तदा पीडितस्तेन कपिना पर्वतोत्तमः ।\nररास सह तोयेन तेन विस्रावयंस्तदा ॥",
    translation: {
      english: "Pressed by the monkey, that great mountain roared, releasing water from its streams.",
      hindi: "उस वानर द्वारा दबाए जाने पर वह श्रेष्ठ पर्वत गरजने लगा और जल के झरने बहाने लगा।",
      telugu: "ఆ వానరునిచే నొక్కివేయబడిన ఆ పర్వతరాజము గర్జించి, నీటి ధారలను వదిలింది."
    },
    imageType: 'mountain'
  },
  {
    id: "5",
    context: "Flying through the sky.",
    sanskrit: "उत्पातेन सुवेगेन पक्षवानिव पर्वतः ।\nप्रजगाम खमाविश्य पतन्निव समीरणः ॥",
    translation: {
      english: "With great speed, he flew into the sky like a winged mountain, moving like the wind itself.",
      hindi: "अत्यंत वेग से वे आकाश में उड़ चले, मानो पंख वाला पर्वत हो, वायु की तरह गतिमान।",
      telugu: "గొప్ప వేగంతో ఆయన ఆకాశంలోకి ఎగిరారు, రెక్కలున్న పర్వతంలా, గాలిలా కదులుతూ."
    },
    imageType: 'departure'
  },
  {
    id: "6",
    context: "Mainaka Mountain rises.",
    sanskrit: "उत्तिष्ठ त्वं महाशैल मैनाक लवणाम्भसि ।\nहनुमान् रामकार्यार्थं भीमकर्मा समुद्यतः ॥",
    translation: {
      english: "O great mountain Mainaka, rise from the salt ocean! Hanuman is engaged in a formidable task for Rama.",
      hindi: "हे महाशैल मैनाक! तुम लवण सागर से उठो। हनुमान राम के कार्य के लिए उद्यत हैं।",
      telugu: "ఓ మైనాక పర్వతమా! ఉప్పు సముద్రం నుండి లెమ్ము. హనుమంతుడు రాముని కార్యము కొరకు సిద్ధమయ్యాడు."
    },
    imageType: 'mountain'
  },
  {
    id: "7",
    context: "Encounter with Surasa.",
    sanskrit: "प्रविशस्य वदनं मे अद्य गन्तुं त्वमर्हसि ।\nवर एष पुरा दत्तो मम धात्रेति सत्वरा ॥",
    translation: {
      english: "You must enter my mouth before you go today. This boon was given to me by the Creator long ago.",
      hindi: "मेरे मुख में प्रवेश करके ही तुम जा सकते हो। यह वर मुझे विधाता ने बहुत पहले दिया था।",
      telugu: "నా నోటిలో ప్రవేశించిన తర్వాతే నీవు వెళ్ళగలవు. ఈ వరం నాకు సృష్టికర్త ఎప్పుడో ఇచ్చారు."
    },
    imageType: 'surasa'
  },
  {
    id: "8",
    context: "Hanuman outwits Surasa.",
    sanskrit: "ततो वेगेन संक्षिप्य पुनः स्वां तनुमात्मवान् ।\nनिष्पत्य वदनात्तस्याः खेऽतिष्ठन्मारुतात्मजः ॥",
    translation: {
      english: "Shrinking his body quickly, the wise son of Wind exited her mouth and stood in the sky.",
      hindi: "अपनी काया को तुरंत छोटा करके, बुद्धिमान पवनपुत्र उसके मुख से निकलकर आकाश में स्थित हो गए।",
      telugu: "తన శరీరాన్ని వేగంగా తగ్గించుకుని, ఆ వాయుపుత్రుడు ఆమె నోటి నుండి బయటకు వచ్చి ఆకాశంలో నిలిచాడు."
    },
    imageType: 'surasa'
  },
  {
    id: "9",
    context: "Encounter with Simhika.",
    sanskrit: "उत्पातेन हि वेगेन तस्या विवृतमाननम् ।\nनिपात्य सुमहत्कायं निष्पपात ततो बली ॥",
    translation: {
      english: "Dashing with speed into her open mouth, the mighty one destroyed her huge body and emerged.",
      hindi: "तेजी से उसके खुले मुख में घुसकर, उस बली ने उसके विशाल शरीर को नष्ट कर दिया और बाहर निकल आए।",
      telugu: "వేగంగా ఆమె తెరిచిన నోటిలోకి దూకి, ఆ బలశాలి ఆమె భారీ శరీరాన్ని నాశనం చేసి బయటకు వచ్చాడు."
    },
    imageType: 'simhika'
  },
  {
    id: "10",
    context: "Sighting Lanka.",
    sanskrit: "स तदा लम्बमानेन गिरिमात्रेण भास्वता ।\nददर्श लङ्काममलां तिष्ठन्तीं गिरिमूर्धनि ॥",
    translation: {
      english: "Hovering like a shining mountain, he saw the pristine Lanka situated on the mountain peak.",
      hindi: "एक चमकते हुए पर्वत की तरह लटकते हुए, उन्होंने पर्वत के शिखर पर स्थित निर्मल लंका को देखा।",
      telugu: "ప్రకాశించే పర్వతంలా వేలాడుతూ, పర్వత శిఖరంపై ఉన్న నిర్మలమైన లంకను ఆయన చూశారు."
    },
    imageType: 'lanka'
  }
];
